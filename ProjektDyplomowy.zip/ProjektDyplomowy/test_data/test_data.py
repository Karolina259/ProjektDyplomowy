class TestData:

    CHOSEN_PERFUME = "Nomade"
    CHOSEN_MAX_PRICE = "300"
    CATEGORY_COMPONENT = "pielęgnacja ciała"
    CHOSEN_COSMETIC = "krem do twarzy"